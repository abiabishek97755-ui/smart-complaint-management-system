# Smart Complaint Management System

A responsive frontend website for submitting and managing complaints.

## Project Structure

- `index.html` - Complete website (HTML, CSS and JavaScript in one file)
- `README.md` - Project documentation
- `.gitignore` - Git ignore configuration
- `assets/` - Folder for images/icons

## How to Run

Open `index.html` in any modern web browser.

## GitHub Pages

1. Create a new GitHub repository.
2. Upload the project files.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select `main` branch and `/ (root)`.
6. Save and wait for deployment.

## Technologies

HTML5, CSS3, JavaScript
